import pygame,sys,os,time
from pygame.locals import *
from sys import exit

windowres = (600, 350)
screen = pygame.display.set_mode(windowres)
screen.fill((0,0,250))	                        
pygame.display.set_caption("	Hexxagon-By lucky sahani	")
hex=pygame.image.load("im3.png")
obj1=pygame.image.load("im8.png")
obj2=pygame.image.load("im9.png")
obj3=pygame.image.load("im7.png")
obj4=pygame.image.load("im10.png")
obj5=pygame.image.load("im14.png")
mousex = mousey = 0
hexlist1=["empty"]
hexlist2=["empty"]
hexlist3=["empty"]
hexdict1={}
k5=0
templist1=[(520,80),(280,260),(40,80)]
templist2=[(40,200),(280,20),(520,200)]
pygame.mouse.set_pos([450, 350])
pygame.init()
global player
player=1
y1=0
tempx=tempy=0

def main():
	screen.blit(obj5,(0,0))
	while True:
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()		
		mousex,mousey=pygame.mouse.get_pos()		
		pygame.display.flip()
		pygame.display.update()
		(x,y,z)=pygame.mouse.get_pressed()
		pygame.display.flip()
		pygame.display.update()
		if x==1:
			print mousex,mousey
main()
