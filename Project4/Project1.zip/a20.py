import pygame,sys,os,time
from pygame.locals import *
from sys import exit

windowres = (600, 300)
screen = pygame.display.set_mode(windowres)
screen.fill((0,0,250))	                        
pygame.display.set_caption("	Hexxagon-By lucky sahani	")
hex=pygame.image.load("im3.png")
obj1=pygame.image.load("im8.png")
obj2=pygame.image.load("im9.png")
obj3=pygame.image.load("im7.png")
obj4=pygame.image.load("im10.png")
obj5=pygame.image.load("im12.png")
mousex = mousey = 0
hexlist1=["empty"]
hexlist2=["empty"]
hexlist3=["empty"]
hexdict1={}
k5=0
templist1=[(520,80),(280,260),(40,80)]
templist2=[(40,200),(280,20),(520,200)]
pygame.mouse.set_pos([450, 350])
pygame.init()
global player
player=1

def main() :
	
	global mousex,mousey   
	player=1         
	start()	
	displayhexagon()
	hexlistlev1()
	#hexlistlev2()
	while True:
		eventexit()
		mousex,mousey=pygame.mouse.get_pos()		
		pygame.display.flip()
		(x,y,z)=pygame.mouse.get_pressed()
		
		if x==1:
			if is_inside()==True:
			#print"Valid"
				if is_valid(mousex,mousey)==True:
					#print "Valid"	
					is_possible(mousex,mousey)			
					if (player==1)==True:
						nearestcentrecoordinatesdisplay()			
						printmousepos()
						pygame.event.wait()
						addlist()
						displayhex1()
						player=2
						#print "kjso"	
					else :
						nearestcentrecoordinatesdisplay()			
						printmousepos()
						pygame.event.wait()
						addlist()
						displayhex2()
						player=1
				else:
					print "Not valid"
			else:
				print "Not Valid"				
			#clock.tick()	
			#colourchange() 	
		pygame.display.flip()

def is_valid(k1,k2):
	mousx=nearestcentrexcoordinates1(k1,k2)
	mousy=nearestcentreycoordinates1(k1,k2)	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15	
			if  (dist(mousx,mousy,x,y)==900) or (dist(mousx,mousy,x,y)==3825) or (dist(mousx,mousy,x,y)==3600) or (dist(mousx,mousy,x,y)==5625) or (dist(mousx,mousy,x,y)==15300)==True or ((dist(mousx,mousy,x,y)==14400)==True and (abs(mousx-x)==120)) :
				return True
	return False
def is_possible(g1,g2):
	mousx=nearestcentrexcoordinates1(g1,g2)
	mousy=nearestcentreycoordinates1(g1,g2)	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15	
			if  (dist(mousx,mousy,x,y)==900) or (dist(mousx,mousy,x,y)==3825) :
				screen.blit(obj4,(x-30-5-2.5,y-20))
			elif (dist(mousx,mousy,x,y)==3600) or (dist(mousx,mousy,x,y)==5625) or (dist(mousx,mousy,x,y)==15300)==True or ((dist(mousx,mousy,x,y)==14400)==True and (abs(mousx-x)==120)) :
				screen.blit(obj5,(x-50+10+2.5,y-20))
	
def is_inside():
	mousex,mousey=pygame.mouse.get_pos()
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15 :
				return True
	#print"Not Valid"	
	return False
def colourchange():
	if((1/1000)*pygame.time.get_ticks())%7==0:
		screen.fill((250,250,250))	
	elif((1/1000)*pygame.time.get_ticks())%7==1:  
		screen.fill((255,0,0))
	elif((1/1000)*pygame.time.get_ticks())%7==2:  
		screen.fill((0,255,0))
	elif((1/1000)*pygame.time.get_ticks())%7==3:  
		screen.fill((0,0,255))
	elif((1/1000)*pygame.time.get_ticks())%7==4:  
		screen.fill((0,0,0))
	elif((1/1000)*pygame.time.get_ticks())%7==5:  
		screen.fill((0,0,128))
	elif((1/1000)*pygame.time.get_ticks())%7==6:  
		screen.fill((255,200,200))
def start():
	screen.blit(obj1,(490+2.5,65+2.5))
	screen.blit(obj1,(250+2.5,245+2.5))
	screen.blit(obj1,(10+2.5,65+2.5))
	screen.blit(obj2,(490+5+5,180+5+5))
	screen.blit(obj2,(250+5+5,5+5))
	screen.blit(obj2,(10+5+5,180+5+5))

def addlist():
	mousex,mousey=pygame.mouse.get_pos()	
	if(player==1):
		for i in range(9):
			x=(i*60)+40
			for j in range(f(i)):
				y=20+(30*j)+abs(i-4)*15
				if abs(mousex-x)<30 and abs(mousey-y)<15 :
					templist1.append((mousex,mousey))
					templist1.append((x,y))
	else:
		for i in range(9):
			x=(i*60)+40
			for j in range(f(i)):
				y=20+(30*j)+abs(i-4)*15
				if abs(mousex-x)<30 and abs(mousey-y)<15:
					templist2.append((mousex,mousey))
					templist2.append((x,y))
		


def dist(x,y,a,b):
	return (((x-a)**2) + ((y-b)**2))
def displayhex1():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:	
				screen.blit(obj1,(x-30+2.5,y-15+2.5))
def displayhex2():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:	
				screen.blit(obj2,(x-20,y-10))
def displayhex3():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:	
				screen.blit(obj4,(x-30+2.5+40+10,y-15+2.5-5))
def displayhex4():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:	
				screen.blit(obj5,(x-30+2.5,y-15+2.5))
def eventexit():
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()
	
def printmousepos():
	mousex,mousey=pygame.mouse.get_pos()
	print mousex,mousey

def nearestcentrecoordinatesdisplay():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:
				print x
				print y					
def nearestcentrexcoordinates():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:
				return x
def nearestcentrexcoordinates1(x1,y1):
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(x1-x)<30 and abs(y1-y)<15:
				return x
def nearestcentreycoordinates1(x1,y1):
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(x1-x)<30 and abs(y1-y)<15:
				return y
def nearestcentreycoordinates():
	mousex,mousey=pygame.mouse.get_pos()	
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			if abs(mousex-x)<30 and abs(mousey-y)<15:
				return y
def f(i):
	if i<5:
		return i+5
	else:
		return 13-i
def displayhexagon():
	for i in range(9):
		x=i*60
		for j in range(f(i)):
			y=30*j+abs(i-4)*15
			screen.blit(hex,(x,y))

def hexlistlev1():
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			hexlist1.append((x,y))		

def hexfindi1():
	mousex,mousey=pygame.mouse.get_pos()
	mousx=nearestcentrexcoordinates()
	mousy=nearestcentreycoordinates()	
	for i in range(61):
		if hexlist1[i]==(mousx,mousy):
			return i
		       	print i

#def 
def hexfindi1(l1,l2):	
	for i in range(61):
		if hexlist1[i]==(l1,l2):
			return i
			print i	
def retallcenterx():
		for i in range(9):
			x=(i*60)+40
			for j in range(f(i)):
				y=20+(30*j)+abs(i-4)*15
				return x	

def retallcentery():
		for i in range(9):
			x=(i*60)+40
			for j in range(f(i)):
				y=20+(30*j)+abs(i-4)*15
				return y	
def hexlistlev2():
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			for i2 in range(9):
				mousx=(i2*60)+40
				for j2 in range(f(i2)):
					mousy=20+(30*j2)+abs(i2-4)*15
					if  (dist(mousx,mousy,x,y)==900) or (dist(mousx,mousy,x,y)==3825) :
						hexlist2.append((hexfindi1(x,y),hexfindi1(mousx,mousy)))	
	hexlist2.pop(294)
	hexlist2.pop(290)
	hexlist2.pop(308)
	hexlist2.pop(308)
	hexlist2.pop(308)
	hexlist2.pop(307)
def hexlistlev3():
	for i in range(9):
		x=(i*60)+40
		for j in range(f(i)):
			y=20+(30*j)+abs(i-4)*15
			for i2 in range(9):
				mousx=(i2*60)+40
				for j2 in range(f(i2)):
					mousy=20+(30*j2)+abs(i2-4)*15
					if  (dist(mousx,mousy,x,y)==900) or (dist(mousx,mousy,x,y)==3825) or (dist(mousx,mousy,x,y)==3600) or (dist(mousx,mousy,x,y)==5625) or (dist(mousx,mousy,x,y)==14400) or (dist(mousx,mousy,x,y)==15300)==True :
						hexlist3.append((hexfindi1(x,y),hexfindi1(mousx,mousy)))
hexlistlev1()
hexlistlev2()
hexlistlev3()

#print hexlist3




main()



