def dist(x,y):
	return ((x**2) + (y**2))

x=dist(2,4)
print x
