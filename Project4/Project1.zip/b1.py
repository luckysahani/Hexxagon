import pygame,sys,os,time
from pygame.locals import *
from sys import exit

windowres = (600, 300)
screen = pygame.display.set_mode(windowres)
screen.fill((0,0,250))	                        
pygame.display.set_caption("	Hexxagon-By lucky sahani	")
pygame.init()
global player
player=1
tempx=tempy=0

def main() :
	
	global mousex,mousey   
	player=1         
	#start()	
	#displayhexagon()
	#hexlistlev1()
	#hexlistlev2()
	while True:
		eventexit()
		mousex,mousey=pygame.mouse.get_pos()		
		pygame.display.flip()
		(x,y,z)=pygame.mouse.get_pressed()
		tempx=mousex
		tempy=mousey
		if x==1:
			pygame.event.get()
			pygame.event.wait()
			x9,y9,z9=pygame.mouse.get_pressed()
			mousex,mousey=pygame.mouse.get_pos()
			h1,h2=mousex,mousey
			x=0
			pygame.display.flip()
			print mousex,mousey
			print x9
			if x9==1:
				print "Y"

def eventexit():
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()

main()
